<script>
import MyContent from "@/components/HomeContent/myContent.vue";

export default {
  name: "homepage",
  components: {MyContent}
}
</script>

<template>
<MyContent></MyContent>

</template>

<style scoped>

</style>